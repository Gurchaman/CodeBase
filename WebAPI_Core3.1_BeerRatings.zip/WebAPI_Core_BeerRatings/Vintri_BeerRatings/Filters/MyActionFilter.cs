﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Text.RegularExpressions;
using BeerRatings.Models;

namespace BeerRatings.Filters
{
    public class MyActionFilter : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {

        }

        public void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var UserName = (UserRatingsModel)actionContext.ActionArguments["objUserRatings"];

            Regex regex = new Regex(Constants.UserNameRegex);
            Match match = regex.Match(UserName.UserName);

            if (!match.Success)
                actionContext.RouteData.Values.Add("InvalidUserName", Messages.InValidUserName);
        }
    }
}
